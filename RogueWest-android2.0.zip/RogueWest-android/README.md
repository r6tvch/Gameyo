# RogueWest для Android

Внутри Android-приложение: полноэкранный WebView с игрой из `app/src/main/assets/index.html`.
Горизонтальная ориентация, экран не гаснет, системные кнопка «Назад» = пауза / назад в меню.
Сохранения (монеты, вещи, профили игроков) хранятся внутри приложения.

## Способ 1. Без компьютера: GitHub собирает APK сам
1. Зарегистрируйся на github.com, создай новый репозиторий (Public или Private).
2. Распакуй архив и загрузи **всё содержимое** папки RogueWest-android в репозиторий
   (Add file → Upload files). Важно, чтобы загрузилась скрытая папка `.github`.
   Если папка `.github` не загрузилась: в репозитории нажми Add file → Create new file,
   имя `.github/workflows/build-apk.yml` и вставь текст из этого файла.
3. Открой вкладку **Actions** — сборка запустится сама (или нажми Build APK → Run workflow).
4. Через 3–5 минут открой готовую сборку и внизу скачай **RogueWest-apk** (zip с `app-release.apk`).
5. Перекинь APK на телефон, открой и разреши установку из неизвестных источников.

## Способ 2. Android Studio на компьютере
1. File → Open → выбери папку RogueWest-android, дождись синхронизации Gradle.
2. Build → Build App Bundle(s) / APK(s) → Build APK(s).
3. Готовый файл: `app/build/outputs/apk/debug/app-debug.apk`.

## Обновить игру
Замени `app/src/main/assets/index.html` новой версией и пересобери.
При обновлении увеличь `versionCode` в `app/build.gradle`, тогда APK встанет поверх старого
без потери сохранений.

Шрифты подгружаются из интернета; без сети игра работает, но с запасными шрифтами.
